# CandleSMP 1.0.0

Source project for a Bukkit-compatible Candle SMP plugin.

## Features
- First join assigns one random candle (six types) and saves it by UUID.
- Right-click the special candle to activate its ability.
- 15-second cooldown.
- `/candle`, `/candle help`, `/candle list`, `/candle power`
- Admin: `/candle give <player> <type>` and `/candle set <player> <type>`
- Candle types: EMBER, FROST, BLOOM, STORM, SHADOW, WIND
- Admin permission: `candlesmp.admin` (OP by default)

## Build
Requires Java 21 and Maven. Run `mvn package`. The output jar is in `target/CandleSMP-1.0.0.jar`.

## Install
Copy the built jar into `plugins/` and restart the server.

## Compatibility note
The plugin uses the Bukkit API and `api-version: '1.21'` to target the 1.21 API line. It is designed for Paper/Spigot 1.21.x, but must be built and tested against each target server version before calling it fully verified. This environment could not download dependencies or compile the jar, so this ZIP contains source code, not a prebuilt JAR.

package com.arnav.candlesmp;

import java.util.*;
import org.bukkit.*;
import org.bukkit.command.*;
import org.bukkit.entity.*;
import org.bukkit.event.*;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.inventory.*;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;

public final class CandleSMP extends JavaPlugin implements Listener, CommandExecutor {
    private NamespacedKey candleKey;
    private final Map<UUID, Long> cooldowns = new HashMap<>();
    private final Random random = new Random();

    private enum Candle {
        EMBER("Ember", Material.RED_CANDLE, ChatColor.RED, "Fire resistance + speed"),
        FROST("Frost", Material.LIGHT_BLUE_CANDLE, ChatColor.AQUA, "Slows nearby players"),
        BLOOM("Bloom", Material.LIME_CANDLE, ChatColor.GREEN, "Restores health and hunger"),
        STORM("Storm", Material.YELLOW_CANDLE, ChatColor.YELLOW, "Lightning visual + speed"),
        SHADOW("Shadow", Material.PURPLE_CANDLE, ChatColor.DARK_PURPLE, "Short invisibility"),
        WIND("Wind", Material.WHITE_CANDLE, ChatColor.WHITE, "Jump boost + slow falling");

        final String display;
        final Material material;
        final ChatColor color;
        final String description;
        Candle(String display, Material material, ChatColor color, String description) {
            this.display = display; this.material = material; this.color = color; this.description = description;
        }
        static Candle parse(String s) {
            for (Candle c : values()) if (c.name().equalsIgnoreCase(s) || c.display.equalsIgnoreCase(s)) return c;
            return null;
        }
    }

    @Override public void onEnable() {
        candleKey = new NamespacedKey(this, "candle_type");
        saveDefaultConfig();
        Objects.requireNonNull(getCommand("candle")).setExecutor(this);
        getServer().getPluginManager().registerEvents(this, this);
        getLogger().info("CandleSMP enabled!");
    }

    @EventHandler public void onJoin(PlayerJoinEvent event) {
        Player p = event.getPlayer();
        String path = "players." + p.getUniqueId();
        if (!getConfig().contains(path)) {
            Candle c = Candle.values()[random.nextInt(Candle.values().length)];
            getConfig().set(path, c.name());
            saveConfig();
            p.sendMessage(ChatColor.GOLD + "🕯 Welcome to Candle SMP! Your random candle is " + c.color + c.display + ChatColor.GOLD + "!");
            giveCandle(p, c);
        } else {
            Candle c = Candle.parse(getConfig().getString(path, ""));
            if (c != null && !hasCandle(p, c)) giveCandle(p, c);
        }
    }

    private ItemStack makeCandle(Candle c) {
        ItemStack item = new ItemStack(c.material);
        ItemMeta meta = item.getItemMeta();
        meta.setDisplayName(c.color + "" + ChatColor.BOLD + c.display + " Candle");
        meta.setLore(Arrays.asList(ChatColor.GRAY + "Candle SMP Ability", ChatColor.YELLOW + "Right-click to activate", ChatColor.DARK_GRAY + c.description));
        meta.getPersistentDataContainer().set(candleKey, PersistentDataType.STRING, c.name());
        item.setItemMeta(meta);
        return item;
    }

    private void giveCandle(Player p, Candle c) {
        p.getInventory().addItem(makeCandle(c)).values().forEach(item -> p.getWorld().dropItemNaturally(p.getLocation(), item));
    }

    private boolean hasCandle(Player p, Candle c) {
        for (ItemStack item : p.getInventory().getContents()) {
            if (item == null || !item.hasItemMeta()) continue;
            String type = item.getItemMeta().getPersistentDataContainer().get(candleKey, PersistentDataType.STRING);
            if (c.name().equals(type)) return true;
        }
        return false;
    }

    @EventHandler public void onUse(PlayerInteractEvent event) {
        if (event.getHand() != EquipmentSlot.HAND) return;
        if (event.getAction() != org.bukkit.event.block.Action.RIGHT_CLICK_AIR &&
            event.getAction() != org.bukkit.event.block.Action.RIGHT_CLICK_BLOCK) return;
        ItemStack item = event.getItem();
        if (item == null || !item.hasItemMeta()) return;
        String type = item.getItemMeta().getPersistentDataContainer().get(candleKey, PersistentDataType.STRING);
        Candle c = Candle.parse(type == null ? "" : type);
        if (c == null) return;
        event.setCancelled(true);
        Player p = event.getPlayer();
        long now = System.currentTimeMillis();
        long ready = cooldowns.getOrDefault(p.getUniqueId(), 0L);
        if (now < ready) {
            p.sendMessage(ChatColor.RED + "Candle is recharging for " + ((ready - now + 999) / 1000) + "s.");
            return;
        }
        activate(p, c);
        cooldowns.put(p.getUniqueId(), now + 15000L);
    }

    private void activate(Player p, Candle c) {
        switch (c) {
            case EMBER -> {
                p.addPotionEffect(new PotionEffect(PotionEffectType.FIRE_RESISTANCE, 20 * 8, 0));
                p.addPotionEffect(new PotionEffect(PotionEffectType.SPEED, 20 * 8, 1));
                p.getWorld().spawnParticle(Particle.FLAME, p.getLocation().add(0, 1, 0), 35, .5, .6, .5, .02);
            }
            case FROST -> {
                for (Entity e : p.getNearbyEntities(5, 5, 5)) {
                    if (e instanceof Player target && target != p) {
                        target.addPotionEffect(new PotionEffect(PotionEffectType.SLOWNESS, 20 * 4, 1));
                        target.getWorld().spawnParticle(Particle.SNOWFLAKE, target.getLocation().add(0, 1, 0), 20, .4, .6, .4, .01);
                    }
                }
                p.getWorld().spawnParticle(Particle.SNOWFLAKE, p.getLocation().add(0, 1, 0), 35, 1, 1, 1, .02);
            }
            case BLOOM -> {
                p.setHealth(Math.min(p.getMaxHealth(), p.getHealth() + 6.0));
                p.setFoodLevel(Math.min(20, p.getFoodLevel() + 6));
                p.addPotionEffect(new PotionEffect(PotionEffectType.REGENERATION, 20 * 5, 1));
                p.getWorld().spawnParticle(Particle.HAPPY_VILLAGER, p.getLocation().add(0, 1, 0), 25, .5, .7, .5, .05);
            }
            case STORM -> {
                p.addPotionEffect(new PotionEffect(PotionEffectType.SPEED, 20 * 6, 1));
                p.getWorld().strikeLightningEffect(p.getLocation());
                p.getWorld().spawnParticle(Particle.ELECTRIC_SPARK, p.getLocation().add(0, 1, 0), 35, .6, .8, .6, .05);
            }
            case SHADOW -> {
                p.addPotionEffect(new PotionEffect(PotionEffectType.INVISIBILITY, 20 * 6, 0));
                p.addPotionEffect(new PotionEffect(PotionEffectType.SPEED, 20 * 6, 0));
                p.getWorld().spawnParticle(Particle.SMOKE, p.getLocation().add(0, 1, 0), 30, .5, .7, .5, .02);
            }
            case WIND -> {
                p.addPotionEffect(new PotionEffect(PotionEffectType.JUMP_BOOST, 20 * 8, 2));
                p.addPotionEffect(new PotionEffect(PotionEffectType.SLOW_FALLING, 20 * 8, 0));
                p.getWorld().spawnParticle(Particle.CLOUD, p.getLocation().add(0, 1, 0), 30, .5, .3, .5, .03);
            }
        }
        p.sendMessage(ChatColor.GOLD + "🕯 " + c.color + c.display + ChatColor.GOLD + " Candle activated! " + ChatColor.GRAY + "(15s cooldown)");
        p.playSound(p.getLocation(), Sound.BLOCK_AMETHYST_BLOCK_CHIME, 1f, 1.4f);
    }

    @Override public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (args.length == 0 || args[0].equalsIgnoreCase("help")) {
            sender.sendMessage(ChatColor.GOLD + "==== Candle SMP ====");
            sender.sendMessage(ChatColor.YELLOW + "/candle power " + ChatColor.GRAY + "- show your candle");
            sender.sendMessage(ChatColor.YELLOW + "/candle list " + ChatColor.GRAY + "- list all candles");
            sender.sendMessage(ChatColor.YELLOW + "/candle give <player> <type> " + ChatColor.GRAY + "- admin");
            sender.sendMessage(ChatColor.YELLOW + "/candle set <player> <type> " + ChatColor.GRAY + "- admin");
            return true;
        }
        if (args[0].equalsIgnoreCase("list")) {
            for (Candle c : Candle.values()) sender.sendMessage(c.color + c.display + ChatColor.GRAY + " — " + c.description);
            return true;
        }
        if (args[0].equalsIgnoreCase("power")) {
            if (!(sender instanceof Player p)) { sender.sendMessage("Only players can use this command."); return true; }
            Candle c = Candle.parse(getConfig().getString("players." + p.getUniqueId(), ""));
            sender.sendMessage(c == null ? ChatColor.RED + "You don't have a candle assigned." :
                ChatColor.GOLD + "Your candle: " + c.color + c.display + ChatColor.GRAY + " — " + c.description);
            sender.sendMessage(ChatColor.YELLOW + "Hold your candle and right-click to activate (15s cooldown).");
            return true;
        }
        if (!sender.hasPermission("candlesmp.admin")) {
            sender.sendMessage(ChatColor.RED + "You need candlesmp.admin permission.");
            return true;
        }
        if ((args[0].equalsIgnoreCase("give") || args[0].equalsIgnoreCase("set")) && args.length >= 3) {
            Player target = Bukkit.getPlayerExact(args[1]);
            Candle c = Candle.parse(args[2]);
            if (target == null) { sender.sendMessage(ChatColor.RED + "Player must be online."); return true; }
            if (c == null) { sender.sendMessage(ChatColor.RED + "Unknown candle. Use /candle list."); return true; }
            if (args[0].equalsIgnoreCase("set")) {
                getConfig().set("players." + target.getUniqueId(), c.name());
                saveConfig();
            }
            giveCandle(target, c);
            sender.sendMessage(ChatColor.GREEN + "Gave " + c.display + " Candle to " + target.getName() + ".");
            target.sendMessage(ChatColor.GOLD + "You received the " + c.color + c.display + ChatColor.GOLD + " Candle!");
            return true;
        }
        sender.sendMessage(ChatColor.RED + "Usage: /candle help");
        return true;
    }
}
